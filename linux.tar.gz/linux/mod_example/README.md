Example modification
====================

To compile this modification, use ndk-build in this directory. Then you should copy the output .so from libs/x86/ to the launcher's mods/ directory.
