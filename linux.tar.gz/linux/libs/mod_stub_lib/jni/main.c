void* mcpelauncher_hook(void* sym, void* hook, void* org) {
	//
}
void mcpelauncher_unhook(void* hook) {
	//
}
